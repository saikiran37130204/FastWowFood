<head>

	<title>FastWoWFood</title>

	<meta charset="utf-8">

	<link rel="icon" type="image/x-icon" href="../assets/favicon.ico">

	<meta name="viewport" content="width=device-width,initial-scale=1.0">

	<!-- css -->

	<link rel="stylesheet" type="text/css" href="../assets/mi_css_global.css">

	<!-- js -->

	<script src="../assets/jquery-3.6.0.js"></script>

	<script src="../assets/globaljavascript.js"></script>

	<!-- icons -->

	<link rel="stylesheet" type="text/css" href="../assets/icons/css/all.css">

	<link rel="stylesheet" type="text/css" href="../assets/icons/css/all.min.css">

	<link rel="stylesheet" type="text/css" href="../assets/icons/css/brands.css">

	<link rel="stylesheet" type="text/css" href="../assets/icons/css/brands.min.css">

	<link rel="stylesheet" type="text/css" href="../assets/icons/css/fontawesome.css">

	<link rel="stylesheet" type="text/css" href="../assets/icons/css/fontawesome.min.css">

	<link rel="stylesheet" type="text/css" href="../assets/icons/css/regular.css">

	<link rel="stylesheet" type="text/css" href="../assets/icons/css/regular.min.css">

	<link rel="stylesheet" type="text/css" href="../assets/icons/css/solid.css">

	<link rel="stylesheet" type="text/css" href="../assets/icons/css/solid.min.css">

	<link rel="stylesheet" type="text/css" href="../assets/icons/css/svg-with-js.css">

	<link rel="stylesheet" type="text/css" href="../assets/icons/css/svg-with-js.min.css">

	<link rel="stylesheet" type="text/css" href="../assets/icons/css/v4-font-face.css">

	<link rel="stylesheet" type="text/css" href="../assets/icons/css/v4-font-face.min.css">

	<link rel="stylesheet" type="text/css" href="../assets/icons/css/v4-shims.css">

	<link rel="stylesheet" type="text/css" href="../assets/icons/css/v4-shims.min.css">

	<link rel="stylesheet" type="text/css" href="../assets/icons/css/v5-font-face.css">

	<link rel="stylesheet" type="text/css" href="../assets/icons/css/v5-font-face.min.css">

</head>

