<img src="../assets/logo.png" class="my_logo">


<div class="container" id="admin_nav">
	
	<a href="homepage.php" class="adminlinks">Home</a>

	<a href="myorders.php" class="adminlinks">My Orders</a>
	
	<a href="logout.php" class="adminlinks">Logout</a>

</div>