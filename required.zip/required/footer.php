<div class="container" style="flex-grow: 1;">
				
	<div class="container_8">
		
		<p class="label_headers">Welcome</p>

	</div>

</div>

<div class="container" style="flex-grow: 3">
	
	<div class="container_8">
		
		<p class="label_headers">Copyright @<?php echo date('Y'); ?></p>

	</div>

</div>