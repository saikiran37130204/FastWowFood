<?php 

if ($person_type !== "Admin") 
{
	
	echo "<script> window.location = 'homepage.php'; </script>";
}


?>


<img src="../assets/logo.png" class="my_logo">

<div class="container" id="admin_nav">
	
	<a href="adminindex.php" class="adminlinks">Home</a>

	<a href="myorders.php" class="adminlinks">My Orders</a>

	<a href="adminaddproduct.php" class="adminlinks">Add Product</a>

	<a href="adminaddcategory.php" class="adminlinks">Add Category</a>

	<a href="logout.php" class="adminlinks">Logout</a>

</div>