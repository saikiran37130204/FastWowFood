<?php

session_start();

include "../assets/db_connect.php";
include "../assets/proceduresfile.php";

if (isset($_POST['loginaddress']) && isset($_POST['loginverify'])) 
{
	
	$loginaddress	= akhtic_scrap($_POST['loginaddress']);
	$loginverify	= akhtic_scrap($_POST['loginverify']);

	if (empty($loginaddress) || empty($loginverify)) 
	{
		
		echo 'OTP is required';
	}
	else
	{

		// email

		$verifyemail_a	= "SELECT * FROM users_table WHERE email_address = '$loginaddress' ";

		$verifyemail_b	= $db_config->query($verifyemail_a);

		if ($verifyemail_b->num_rows == 1) 
		{
			
			while ($verifyemail = $verifyemail_b->fetch_assoc()) 
			{
			    
			    $LoginValidator 	= $verifyemail['LoginValidator'];
			    $account_id 		= $verifyemail['person_id'];
			    $person_type 		= $verifyemail['person_type'];

			}

			if ($LoginValidator == $loginverify && $LoginValidator !== 0) 
			{
				
				// set session and go ahead

				$validator_a	= "UPDATE users_table SET LoginValidator = '' WHERE email_address = '$loginaddress' ";

				$validator_b	= $db_config->query($validator_a);

				if ($validator_b) 
				{

					//

					$_SESSION['validatedsession']	= $account_id;

					if ($person_type == "Admin") 
					{
						
						echo "<script> window.location = 'adminindex.php'; </script>";
					}
					else
					{

						echo "<script> window.location = 'homepage.php'; </script>";
					}

				}
				else
				{

					echo "Error updating status";
				}
			}
			else
			{

				echo "Invalid OTP. Go to login and resend";
			}

		}
		else
		{

			echo "<script> alert('Invalid account'); window.location = '../index.php'; </script>";
		}
	}

}
else
{

	echo 'Error processing request';
}

?>