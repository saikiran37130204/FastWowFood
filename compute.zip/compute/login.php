<?php

include "../assets/db_connect.php";
include "../assets/proceduresfile.php";
include "sendmail.php";

if (isset($_POST['loginaddress']) && isset($_POST['loginpasscode'])) 
{
	
	$loginaddress	= akhtic_scrap($_POST['loginaddress']);
	$loginpasscode	= akhtic_scrap($_POST['loginpasscode']);

	if (empty($loginaddress) || empty($loginpasscode)) 
	{
		
		echo 'Both fields are required';
	}
	else
	{

		// email

		$verifyemails	= verify_email($loginaddress,$db_config);

		if ($verifyemails == 0) 
		{
			
			echo 'Invalid account. Create account';
		}
		else
		{

			// password

			if ($verifyemails == md5($loginpasscode)) 
			{

				$valiadte		= rand(1000,10001);

				$valiadteid 	= str_shuffle(substr($valiadte, 0,15));

				// send email

				$validator_a	= "UPDATE users_table SET LoginValidator = '$valiadteid' WHERE email_address = '$loginaddress' ";

				$validator_b	= $db_config->query($validator_a);

				if ($validator_b) 
				{
					
					$confirmation_link	= $valiadteid;
					
					$to   = $loginaddress;
                    $from = 'twofactorvalidator@mathiweb.com';
                    $name = 'Mathiweb';
                    $subj = 'LOGIN VALIDATION';
                    $msg = 
                    "
                     <html> 
                        <head> 
                            <title>Validate your login to access account</title> 
                        </head> 
                        <body> 
                        
                            <br>
                            <br>
                            
                            <h3>$confirmation_link</h3>
                            
                        </body> 
                     </html> 
                    ";
                    
					send_email_function($to,$from, $name ,$subj, $msg);

					//
				}
				else
				{

					echo 'Error processing validation';
				}
			}
			else
			{

				echo 'Incorrect password for this account';
			}
		}
	}

}
else
{

	echo 'Error processing request';
}

?>