<?php

include '../screens/global_session.php';

if (isset($_POST['value'])) 
{

	$select_a	= "SELECT * FROM products_table ORDER BY product_name ASC ";

	$select_b 	= $db_config->query($select_a);

	if ($select_b->num_rows > 0) 
	{
		
		//

		while ($select_ = $select_b->fetch_assoc()) 
		{
			
			$get_id 	= $select_['product_id'];


			//. get this valiues

			$get_values 	= products_method($get_id,$db_config);

			if ($get_values !== 0) 
			{
				
				$product_id  			= $get_values['product_id'];
			    $product_name  			= $get_values['product_name'];
			    $product_admin  		= $get_values['product_admin'];
			    $product_price  		= $get_values['product_price'];
			    $product_profile  		= $get_values['product_profile'];
			    $product_date  			= $get_values['product_date'];
			    $product_status  		= $get_values['product_status'];

			    if (strlen($get_values['product_description']) > 231) 
			    {
			    	
			    	$product_description  	= substr($get_values['product_description'], 0,231)."...";
			    }			    

			    //

			    echo 
			    "
			    <div class='container' id='single_container'>

					<div class='container_8'>
					
						<div class='container' id='left_container'>
							
							<img src='../food_profiles/$product_profile' class='single_images'>

						</div>

						<div class='container' id='right_container'>
							
							<p class='label_headers' style='text-transform: uppercase;margin-top: 0px;'><b>$product_name</b></p>

							<p class='label_headers'>$product_description</p>

							<p class='label_headers' style='color: green;margin-bottom: 20px'><b>$ $product_price</b></p>

							<a href='viewproduct.php?id=$product_id' class='view_links'>view</a>

						</div>

					</div>

				</div>

			    ";
			}

		}
	}
}


?>