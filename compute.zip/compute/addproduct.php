<?php

include '../screens/global_session.php';


if (isset($_POST['pro_description']) && isset($_POST['product_name']) && isset($_POST['product_category'])) 
{
	
	//

	foreach ($_FILES as $a => $b) 
	{  

		$filename 		= $b['name'];

		$filesize 		= $b['size'];

		$filetmp 		= $b['tmp_name'];

		$fileType 		= $b['type'];

		$fileSlash		= addslashes($filename);

	}


	$product_name		= akhtic_scrap($_POST['product_name']);

	$product_price		= akhtic_scrap($_POST['product_price']);

	$product_category	= akhtic_scrap($_POST['product_category']);

	$pro_description	= akhtic_scrap($_POST['pro_description']);

	if (empty($product_category) || empty($product_name) || empty($product_price)) 
	{
		
		echo "The primary fields cannot be empty";
	}
	else
	{

		//

		$ext	  			= pathinfo($filename , PATHINFO_EXTENSION);

		$new_images			= random_string(27).".".$ext;

		$product_identity	= random_string(13);

		// validate

		$validate_image		= validateimage($filename,$filesize);

		if ($validate_image == "22") 
		{
			
			echo "Image file is unsupported";

		}
		elseif ($validate_image == "11") 
		{
			
			echo "Image file is too large";

		}
		else
		{

			// upload images

			$move_image		=  move_uploaded_file($filetmp, "../food_profiles/".$new_images);

			if ($move_image) 
			{
				
				// insert the query

				$addproduct_x	= "INSERT INTO products_table(product_id,product_name,product_admin,product_price,product_profile,product_date,product_status,product_description,product_category) VALUES ('$product_identity','$product_name','$person_id','$product_price','$new_images','$current_timestamp','T','$pro_description','$product_category') ";

				$addproduct_y	= $db_config->query($addproduct_x);

				if ($addproduct_y) 
				{
					
					// 

					echo "<script> alert('Success Inserting Product'); location.reload(); </script>";
				}
				else
				{

					echo "Error Processing request";
				}
			}
			else
			{

				echo "Error processing request";
			}
		}

	}

}

?>