<?php

include '../screens/global_session.php';

if (isset($_POST['value'])) 
{

	$select_a	= "SELECT * FROM orders_table WHERE person_id = '$person_id' ORDER BY order_date DESC ";

	$select_b 	= $db_config->query($select_a);

	$entry_		= $select_b->num_rows + 1;

	if ($select_b->num_rows > 0) 
	{
		
		//

		echo 
			"
			<table>
						
				<tr>
					
					<td><b>Entry</b></td>
					<td><b>Product Name</b></td>
					<td><b>Price</b></td>
					<td><b>Items</b></td>
					<td><b>Total Price</b></td>
					<td><b>Address</b></td>
					<td><b>Order Date</b></td>

				</tr>

				";

		while ($select_ = $select_b->fetch_assoc()) 
		{

			$entry_			= $entry_ - 1;
			
			$order_id 		= $select_['order_id'];
			$person_id 		= $select_['person_id'];
			$product_id 	= $select_['product_id'];
			$product_price 	= $select_['product_price'];
			$order_quantity = $select_['order_quantity'];
			$order_date 	= $select_['order_date'];
			$order_status 	= $select_['order_status'];
			$order_address 	= $select_['order_address'];

			// get product name

			$get_name_pr	= products_method($product_id,$db_config);

			if ($get_name_pr == 0) 
			{
				
				$return_name = "Null";
			}
			else
			{

				$return_name = $get_name_pr['product_name'];
			}

			$total_price 	= $product_price * $order_quantity;

			//
			echo 
			"
				<tr>
					
					<td>$entry_.</td>
					<td>$return_name</td>
					<td>$product_price</span></td>
					<td>$order_quantity units</td>
					<td>$ $total_price</td>
					<td>$order_address</td>
					<td>$order_date</td>

				</tr>

			
			 ";	

		}

		echo "</table>";
	}
}


?>