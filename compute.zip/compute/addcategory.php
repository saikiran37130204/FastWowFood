<?php

include '../screens/global_session.php';

if (isset($_POST['category'])) 
{
	
	$category 	= akhtic_scrap($_POST['category']);

	if (empty($category)) 
	{
		
		echo "Category name is required";
	}
	else
	{

		// available

		$available_categories 	= categories($category,$db_config);

		if ($available_categories == 0) 
		{
			
			// insert

			$cat_identity	= rand(999,9999);

			$insert_a		= "INSERT INTO categories_table(category_id,category) VALUES ('$cat_identity','$category') ";

			$insert_b		= $db_config->query($insert_a);

			if ($insert_b) 
			{
				
				echo "<script> alert('Success Inserting Category'); location.reload(); </script>";
			}
			else
			{

				echo "Error processing request";
			}
		}
		else
		{

			echo "Category already added";
		}
	}
}
else
{

	echo "Error processing requets";
}


?>