<?php 

include '../screens/global_session.php';


if (isset($_POST['product_id']) && isset($_POST['product_price']) && isset($_POST['product_quantity']) && isset($_POST['person_address'])) 
{
	
	$product_id			= akhtic_scrap($_POST['product_id']);
	$product_price		= akhtic_scrap($_POST['product_price']);
	$product_quantity	= akhtic_scrap($_POST['product_quantity']);
	$person_address		= akhtic_scrap($_POST['person_address']);

	// 

	if (empty($product_id) || empty($product_price) || empty($product_quantity) || empty($person_address)) 
	{
		
		echo "All fields are required";
	}
	else
	{

		$order_id	= random_string(10);

		$insert_a	= "INSERT INTO orders_table(order_id,person_id,product_id,product_price,order_quantity,order_date,order_status,order_address) VALUES ('$order_id', '$person_id', '$product_id', '$product_price', '$product_quantity', '$current_timestamp', 'T', '$person_address') ";

		$insert_b	= $db_config->query($insert_a);

		if ($insert_b) 
		{
			
			echo "<script> alert('Success placing order'); window.location = 'myorders.php'; </script>";
		}
		else
		{

			echo "Error making order";
		}
	}

}


?>