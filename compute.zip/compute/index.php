<?php 

include "../assets/db_connect.php";
include "../assets/proceduresfile.php";

if (isset($_POST['fullname']) && isset($_POST['emailaddress']) && isset($_POST['passcode']) && isset($_POST['confirmpasscode'])) 
{
	
	$fullname			= akhtic_scrap($_POST['fullname']);
	$emailaddress		= akhtic_scrap($_POST['emailaddress']);
	$passcode			= akhtic_scrap($_POST['passcode']);
	$confirmpasscode	= akhtic_scrap($_POST['confirmpasscode']);

	//

	if (empty($fullname) || strlen($fullname) < 5) 
	{
		
		echo 'Name field must be at least 5 characters';
	}
	else
	{

		// email

		$valid_email	= valid_email($emailaddress);

		if ($valid_email == 1) 
		{
			
			// verify email

			$verifyemails	= verify_email($emailaddress,$db_config);

			if ($verifyemails == 0) 
			{
				
				// password

				if (!($passcode == $confirmpasscode && strlen($passcode) > 7)) 
				{
					
					echo 'Both passwords must be the same and atleast 8 characters';
				}
				else
				{

					$hashpassword	= md5($passcode);

					$account		= rand(9999999999,99999999999999999).str_shuffle("abcdefghijklmnopqrstuvwxyz");

					$accountid 		= str_shuffle(substr($account, 0,20));

					$thisdate		= date('Y-m-d H:i:s');

					//

					$signup_a	= "INSERT INTO users_table (person_id,full_name,email_address,secure_passcode,person_type,date_created,person_status) VALUES ('$accountid','$fullname','$emailaddress','$hashpassword','Customer','$thisdate','T') ";

					$signup_b	= $db_config->query($signup_a);

					if ($signup_b) 
					{
						
						echo "<script> alert('Success creating account. Login to access account'); location.reload(); </script>";

					}
					else
					{

						echo 'Error creating account';
					}
				}

				echo $verifyemails;
			}
			else
			{

				echo 'Email already registered. Please login';
			}
		}
		else
		{

			echo 'Invalid or empty email address';
		}
	}

}
else
{
	echo 'Error processing request';
}


?>