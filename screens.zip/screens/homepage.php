<?php 

include '../screens/global_session.php';


?>

<!DOCTYPE html>
<html>

<?php include '../required/index.php'; ?>

<body>

	<div class="container" id="main_container" style="position: relative;">
		
		<div class="container" id="top_container"> <?php include '../required/topbar.php'; ?> </div>

		<div class="container" id="content_contaner" style="background-color: #f1f1f1;">	

			<div class="container_8" id="load_index"></div>

		</div>

		<div class="container" id="footer_content"> <?php include '../required/footer.php'; ?> </div>

	</div>

	<script type="text/javascript">
		
		$(document).ready(function()
		{

			$("#load_index").load("../compute/loadindex.php", {'value':'value'});

			setInterval(function()
			{

				$("#load_index").load("../compute/loadindex.php", {'value':'value'});

			}, 1000)
		})

	</script>

</body>
</html>