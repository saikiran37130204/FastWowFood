<?php 

include "../assets/db_connect.php";
include "../assets/proceduresfile.php";

if(isset($_GET['token']))
{
    $email  = akhtic_scrap($_GET['token']);
    
    if(empty($email))
    {
        echo "<script> window.location = '../index.php'; </script>";
    }
}
else
{

	echo "<script> window.location = '../index.php'; </script>";
}


?>


<!DOCTYPE html>

<html style="height: 100%">

<?php include '../required/index.php'; ?>

<body style="background-color: #e0f0e3;">
	
	<div class="container" id="flex_container">
		
		<div class="container" id="login_container">
			
			<div class="container_8">
				
				<p class="form_headers">Enter OTP</p>

				<p class="response_headers" id="loginresponse"></p>

				<p class="label_headers">Email Address</p>

				<input type="email" class="input_fields" id="loginaddress" disabled value="<?php echo $email; ?> ">

				<p class="label_headers">OTP</p>

				<input type="number" class="input_fields" id="loginverify">

				<button type="button" class="form_buttons" id="verifybtn"><i class="fa-sharp fa-light fa-right-to-bracket fa-beat-fade"></i>Verify</button>

			</div>

		</div>

	</div>

	<script>
		
		$(document).ready(function()
		{
			$("#verifybtn").click(function()
			{

				var loginaddress	= $("#loginaddress").val();
				var loginverify	    = $("#loginverify").val();

				$.post("../compute/verify.php",
				{
					loginaddress:loginaddress,
					loginverify:loginverify

				}, function(data)
				{

					$("#loginresponse").html(data)
				})

			})

		})

	</script>

</body>
</html>