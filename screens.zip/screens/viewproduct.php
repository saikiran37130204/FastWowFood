<?php 

include 'global_session.php';

if (isset($_GET['id'])) 
{
	
	$get_id 		= akhtic_scrap($_GET['id']);

	$get_values 	= products_method($get_id,$db_config);


	if ($get_values !== 0) 
	{
		
		$product_id  			= $get_values['product_id'];
	    $product_name  			= $get_values['product_name'];
	    $product_admin  		= $get_values['product_admin'];
	    $product_price  		= $get_values['product_price'];
	    $product_profile  		= $get_values['product_profile'];
	    $product_date  			= $get_values['product_date'];
	    $product_status  		= $get_values['product_status'];
	    $product_description  	= $get_values['product_description'];
	    $product_category  		= $get_values['product_category'];

	}
}
else
{

	echo "<script> window.location = 'homepage.php'; </script>";
}


?>


<!DOCTYPE html>
<html>

<?php include '../required/index.php'; ?>

<body>

	<div class="container" id="main_container" style="position: relative;">
		
		<div class="container" id="top_container"> <?php include '../required/topbar.php'; ?> </div>

		<div class="container" id="content_contaner">	

			<div class="container_8">

				<div class="container" id="single_container" style="width: 88%;height: auto;padding-bottom: 10px;">

					<div class="container_8">
					
						<div class="container" id="left_container">
							
							<?php echo "<img src='../food_profiles/$product_profile' class='single_images'>"; ?>

						</div>

						<div class="container" id="right_container">
							
							<p class="label_headers" style="text-transform: uppercase;margin-top: 0px;"><b><?php echo $product_name; ?></b></p>


							<a href="#" class="label_headers" style="text-decoration-line: underline;color: black;"><b><?php echo $product_category ?></b></a>

							<p class="label_headers"><?php echo $product_description; ?></p>

							<p class="label_headers" style="color: green;"><b>$ <?php echo $product_price; ?></b></p>

							<button type="button" class="form_buttons" id="order_button"><i class="fa-sharp fa-light fa-cart-plus fa-beat-fade"></i>Order</button>

							<!-- -->

							<div class="container" id="order_container">
								
								<div class="container_8">
									
									<p class="form_headers">Order here</p>

									<p class="response_headers" id="checkout_response"></p>

									<input type="text" class="input_fields" id="product_id" style="display: none;" value="<?php echo $product_id; ?>">
									<input type="text" class="input_fields" id="product_price" style="display: none;" value="<?php echo $product_price; ?>">			

									<p class="label_headers">Quantity</p>

									<input type="number" class="input_fields" id="product_quantity">

									<p class="label_headers">Address</p>

									<input type="text" class="input_fields" id="person_address">

									<button type="button" class="form_buttons" id="check_out"><i class="fa-sharp fa-light fa-cart-plus fa-beat-fade"></i>Checkout</button>

								</div>

							</div>

							<!-- -->

						</div>

					</div>

				</div>

			</div>

		</div>

		<div class="container" id="footer_content"> <?php include '../required/footer.php'; ?> </div>

	</div>

	<script type="text/javascript">
		
		$(document).ready(function()
		{

			$("#check_out").click(function()
			{

				var	product_id			= $("#product_id").val();
				var	product_price		= $("#product_price").val();
				var	product_quantity	= $("#product_quantity").val();
				var	person_address		= $("#person_address").val();


				var get_confirm			= confirm("Do you want to place this order?");

				if (get_confirm) 
				{

					$.post("../compute/checkout.php",
					{
						product_id:product_id,
						product_price:product_price,
						product_quantity:product_quantity,
						person_address:person_address

					}, function(data)
					{

						$("#checkout_response").html(data)
					})

				}
			})

			//

			$("#order_button").click(function()
			{

				$("#order_button").hide();
				$("#order_container").show();

			})
		})

	</script>

</body>
</html>