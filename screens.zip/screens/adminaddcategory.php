<?php 

include 'global_session.php';


?>

<!DOCTYPE html>
<html>

<?php include '../required/index.php'; ?>

<body>

	<div class="container" id="main_container" style="position: relative;">
		
		<div class="container" id="top_container"> <?php include '../required/adminbar.php'; ?> </div>

		<div class="container" id="content_contaner" style="display: flex;justify-content: center;">	

			<div class="container" id="login_container" style="margin: 10px">
			
				<div class="container_8">
					
					<p class="form_headers">Add category</p>

					<p class="response_headers" id="add_response"></p>

					<p class="label_headers">Category Name</p>

					<input type="email" class="input_fields" id="category">

					<button type="button" class="form_buttons" id="add_button"><i class="fa-sharp fa-light fa-plus fa-beat-fade"></i>Insert</button>

				</div>

			</div>

		</div>

		<div class="container" id="footer_content"> <?php include '../required/footer.php'; ?> </div>

	</div>

	<script type="text/javascript">
		
		$(document).ready(function()
		{

			$("#add_button").click(function()
			{

				var category = $("#category").val();

				$.post("../compute/addcategory.php",
				{
					category:category

				}, function(data)
				{

					$("#add_response").html(data)
				})
			})

		})

	</script>

</body>
</html>