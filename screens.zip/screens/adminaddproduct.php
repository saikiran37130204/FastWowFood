<?php 

include 'global_session.php';


?>

<!DOCTYPE html>
<html>

<?php include '../required/index.php'; ?>

<body>

	<script>
		
		var loadFile = function(event) 
		{
			var image =	document.getElementById('output');

			image.src = URL.createObjectURL(event.target.files[0]);

		};


	</script>

	<div class="container" id="main_container" style="position: relative;">
		
		<div class="container" id="top_container"> <?php include '../required/adminbar.php'; ?> </div>

		<div class="container" id="content_contaner" style="display: flex;justify-content: center;">	

			<div class="container" id="login_container" style="margin: 10px">
			
				<div class="container_8">
					
					<p class="form_headers">Add product</p>

					<p class="response_headers" id="adding_response"></p>

					<p class="label_headers">Product Name</p>

					<input type="text" class="input_fields" id="product_name">

					<p class="label_headers">Product Price</p>

					<input type="number" class="input_fields" id="product_price">

					<p class="label_headers">Product Category</p>

					<select class="input_fields" id="product_category">
						
						<option disabled="" selected>Select Category</option>

							<?php 

								$categories_x	= "SELECT * FROM categories_table ORDER BY category ASC ";

								$categories_y	= $db_config->query($categories_x);

								while ($categories = $categories_y->fetch_assoc()) 
								{
									
									$category		= $categories['category'];

									$category_id	= $categories['category_id'];

									echo "<option value='$category'>$category</option>";

								}

							?>	

					</select>

					<p class="label_headers">Description</p>

					<textarea id="pro_description" class="textarea_fields"></textarea>

					<p class="label_headers">Product Profile</p>

					<input type="file" id="select_images" onchange="loadFile(event)" name="" style="display: none">

					<img id="output"  class="upload_container" >

					<button id="click_upload"><i class="fa-thin fa-image fa-2xl"></i></button>

					<button type="button" class="form_buttons" id="uploadproduct_button"><i class="fa-sharp fa-light fa-circle-plus"></i>Insert</button>

				</div>

			</div>

		</div>

		<div class="container" id="footer_content"> <?php include '../required/footer.php'; ?> </div>

	</div>

	<script>
		
		$(document).ready(function()
		{

			//

			$("#uploadproduct_button").click(function()
			{

				var file 				= $("#select_images")[0].files;

				var product_name		= $("#product_name").val();

				var product_price		= $("#product_price").val();

				var product_category	= $("#product_category").val();

				var pro_description		= $("#pro_description").val();


				if (file.length == 1 ) 
				{

					var formdata	= new FormData();

					for (var i = 0; i < file.length; i++) 
					{
						formdata.append(file[i].name,file[i]);
						formdata.append('product_name',product_name);
						formdata.append('product_price',product_price);
						formdata.append('product_category',product_category);
						formdata.append('pro_description',pro_description);
					}

					$.ajax({
						url:'../compute/addproduct.php',
						type:'post',
						data:formdata,
						contentType:false,
						processData:false,
						success:function(res){

							$("#adding_response").html(res);
						}
					});
				}
				else
				{
					alert("Only one image is allowed for upload");
				}
			})

			//

			$("#click_upload").click(function()
			{

				$("#select_images")[0].click();

			})

			//

			//
		})

	</script>

</body>
</html>