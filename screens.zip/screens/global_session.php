<?php 

session_start();


include "../assets/db_connect.php";
include "../assets/proceduresfile.php";


date_default_timezone_set('Africa/Nairobi');


$current_timestamp		= date('Y-m-d H:i:s');


if (isset($_SESSION['validatedsession'])) 
{
	
	$person_id 		= akhtic_scrap($_SESSION['validatedsession']);

	// get data

	$valid_data		= normal_users($person_id,$db_config);

	if ($valid_data == 0) 
	{
		
		echo "<script> window.location = 'logout.php'; </script>";
	}
	else
	{

		$person_id 			= $valid_data['person_id'];
		$full_name			= $valid_data['full_name'];
	    $email_address		= $valid_data['email_address'];
	    $secure_passcode	= $valid_data['secure_passcode'];
	    $person_type		= $valid_data['person_type'];
	    $date_created		= $valid_data['date_created'];
	    $person_status		= $valid_data['person_status'];

	}

}
else
{

	echo "<script> window.location = 'logout.php'; </script>";
}

?>