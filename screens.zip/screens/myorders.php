<?php 

include '../screens/global_session.php';


?>

<!DOCTYPE html>
<html>

<?php include '../required/index.php'; ?>

<body>

	<div class="container" id="main_container" style="position: relative;">
		
		<div class="container" id="top_container"> <?php include '../required/topbar.php'; ?> </div>

		<div class="container" id="content_contaner">	

			<div class="container_8">
				
				<div class="container" id="myorders_container"></div>

			</div>

		</div>

	</div>

	<script type="text/javascript">
		
		$(document).ready(function()
		{

			$("#myorders_container").load("../compute/loadmyorders.php", {'value':'value'});

			setInterval(function()
			{

				$("#myorders_container").load("../compute/loadmyorders.php", {'value':'value'});

			}, 1000)
		})

	</script>

</body>

</html>